General features
================

