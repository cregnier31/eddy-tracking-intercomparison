Time grid computation
=====================
