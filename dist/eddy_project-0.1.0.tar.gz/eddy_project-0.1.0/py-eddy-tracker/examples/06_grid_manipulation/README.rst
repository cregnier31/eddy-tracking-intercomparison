Grid Manipulation
=================
